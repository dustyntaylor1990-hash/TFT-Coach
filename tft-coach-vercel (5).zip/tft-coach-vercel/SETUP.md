# TFT Forge Coach — Setup Guide

## What you need
- A free Vercel account (vercel.com)
- A free GitHub account (github.com)
- Your Riot API key (developer.riotgames.com — refresh every 24h)
- Your Claude API key (console.anthropic.com — one-time setup)

---

## Step 1 — Create a GitHub repo

1. Go to github.com and sign in (or create a free account)
2. Click the "+" icon → "New repository"
3. Name it `tft-coach`
4. Set it to **Public**
5. Click "Create repository"
6. Upload ALL the files from this folder:
   - `api/riot.js`
   - `public/index.html`
   - `vercel.json`
   - `package.json`

---

## Step 2 — Deploy to Vercel

1. Go to vercel.com and sign in with your GitHub account
2. Click "Add New Project"
3. Select your `tft-coach` repository
4. Click "Deploy" (default settings are fine)
5. Wait ~30 seconds — Vercel will give you a URL like `tft-coach-abc123.vercel.app`

---

## Step 3 — Add your Riot API key

1. In your Vercel project dashboard, go to **Settings → Environment Variables**
2. Add a new variable:
   - Name: `RIOT_API_KEY`
   - Value: your Riot API key (e.g. `RGAPI-xxxxxxxx-...`)
3. Click Save
4. Go to **Deployments** and click **Redeploy** so the key takes effect

> ⚠️ You need to update this variable every 24 hours since dev keys expire.
> For a permanent key, apply for a "Personal API Key" on the Riot developer portal.

---

## Step 4 — Use the app

1. Open your Vercel URL on any device
2. Enter your Claude API key in Settings (only needed once per session)
3. Type your Riot ID (e.g. `Bahagabag#NA1`) and click Fetch
4. Your matches load automatically
5. Select specific matches or leave all selected, then click "Analyze & Coach Me"

---

## Updating your Riot API key (every 24h)

1. Go to developer.riotgames.com → regenerate key
2. Go to vercel.com → your project → Settings → Environment Variables
3. Update `RIOT_API_KEY` with the new value
4. Redeploy

---

## Applying for a permanent Riot API key

If you want to skip the daily key refresh:
1. Go to developer.riotgames.com
2. Click "Register Product"  
3. Apply for a "Personal API Key" — it's free and doesn't expire
4. Approval usually takes a few days
